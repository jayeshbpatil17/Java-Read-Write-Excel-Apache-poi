package com.Excel;

import java.io.File;
import java.io.FileOutputStream;
import java.util.ArrayList;

import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.xssf.usermodel.XSSFRow;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;

public class ExcelUtil {

	public static void main(String[] args) {
		getRowCount();
		getCellData();
	}
	
	
public static void  getCellData() {
		
		String SheetPath = "./data/TestData.xlsx";
		try {
		XSSFWorkbook workbook = new XSSFWorkbook(SheetPath);
		XSSFSheet sheet =workbook.getSheet("Sheet1");
		int rowCount = sheet.getPhysicalNumberOfRows();
		System.out.println("no of row " +rowCount);
		}catch(Exception e) {
			System.out.println(e);
		}
}
	
	
	public static void  getRowCount() {
		XSSFRow row;
		int rowid =1;
		 int cellid = 0;
		 
		 
		ArrayList<String> ary = new ArrayList<String>();
		
		String SheetPath = "./data/TestData.xlsx";
		try {
		XSSFWorkbook workbook = new XSSFWorkbook(SheetPath);
		XSSFSheet sheet =workbook.getSheet("Sheet1");
		XSSFSheet sheet2 =workbook.getSheet("Sheet2");
		int rowCount = sheet.getPhysicalNumberOfRows();
		//System.out.println("no of row " +rowCount);
		for(int i=1;i<rowCount;i++) {
			String value = sheet.getRow(i).getCell(0).getStringCellValue();
			//System.out.println(value);
			ary.add(value);
			//sheet2.createRow(i).createCell(0).setCellValue(value);
		}
//		String value = sheet.getRow(1).getCell(0).getStringCellValue();
//		System.out.println(value);
		
		for (String key : ary) {
			  
            row = sheet2.createRow(rowid++);
           
            Cell cell = row.createCell(cellid++);
           
                cell.setCellValue((String)key);
            }
       
  
//         .xlsx is the format for Excel Sheets...
//         writing the workbook into the file...
        FileOutputStream out = new FileOutputStream(
            new File(SheetPath));
  
        workbook.write(out);
        out.close();
		
		
		
		}catch(Exception e) {
			System.out.println(e);
		}
		
	}
	
}
