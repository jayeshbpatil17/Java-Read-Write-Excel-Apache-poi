package com.JavaExcel;


	import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
	import java.util.ArrayList;
import java.util.List;

import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.xssf.usermodel.XSSFRow;
	import org.apache.poi.xssf.usermodel.XSSFSheet;
	import org.apache.poi.xssf.usermodel.XSSFWorkbook;

	public class ReadWriteExcel {

		public static void main(String[] args) {
			int cellnum = 0;
			int a=1;
			
			
			ArrayList<String> ary = new ArrayList<String>();
			String SheetPath = "./data/TestData.xlsx";
			
			
			getRowCount(SheetPath, ary);
			
			System.out.println(ary);
			WriteExcel(SheetPath, ary, a, cellnum);
	
}
		
		public   static void  getRowCount(String SheetPath, List<String> ary){
			
			try {
				//FileInputStream inputStream = new FileInputStream(new File(SheetPath));
				//FileOutputStream outputStream = new FileOutputStream(SheetPath);
				
			XSSFWorkbook workbook = new XSSFWorkbook(SheetPath);
			XSSFSheet sheet =workbook.getSheet("Sheet1");
			//XSSFSheet sheet2 =workbook.getSheet("Sheet2");
			int rowCount = sheet.getPhysicalNumberOfRows();
			
		
			
			//System.out.println("no of row " +rowCount);
			for(int i=1;i<rowCount;i++) {
				String value = sheet.getRow(i).getCell(0).getStringCellValue();
				System.out.println(value);
				ary.add(value);
			
				 }
			//inputStream.close();
			
			//FileOutputStream outputStream = new FileOutputStream(SheetPath);
			workbook.close();
            //outputStream.close();
			}catch(Exception e) {
				System.out.println(e);
			}
		}

		
public static void WriteExcel(String SheetPath , List<String> ary , int a, int cellnum) {
			
	
	try {
		FileInputStream inputStream = new FileInputStream(new File(SheetPath));
//		FileOutputStream outputStream = new FileOutputStream(SheetPath);
			XSSFWorkbook workbook = new XSSFWorkbook(inputStream);
			XSSFSheet sheet2 =workbook.getSheet("Sheet2");
			
			for(String s :ary) {
				
				Row row = sheet2.createRow(a);
				 Cell cell = row.createCell(cellnum);
				 cell.setCellValue((String)s);
				 a++;
			}
			inputStream.close();
			FileOutputStream outputStream = new FileOutputStream(SheetPath);
			workbook.write(outputStream);
            workbook.close();
            outputStream.close();
			
		}catch (Exception e) {
			// TODO: handle exception
			System.out.println(e);
		}
	
		
	}
			
}
		
	
		
//	public static void  getCellData() {
//			
//			String SheetPath = "./data/TestData.xlsx";
//			try {
//			XSSFWorkbook workbook = new XSSFWorkbook(SheetPath);
//			XSSFSheet sheet =workbook.getSheet("Sheet1");
//			int rowCount = sheet.getPhysicalNumberOfRows();
//			System.out.println("no of row " +rowCount);
//			}catch(Exception e) {
//				System.out.println(e);
//			}
//	}
//		
		
//		public static void  getRowCount() {
//			//XSSFRow row;
//			int cellnum = 0;
//			 int rownum = 0;
//			int rowid =1;
//			 int cellid = 0;
//			 
//			 
//			ArrayList<String> ary = new ArrayList<String>();
//			
//			String SheetPath = "./data/TestData.xlsx";
//			try {
//			XSSFWorkbook workbook = new XSSFWorkbook(SheetPath);
//			XSSFSheet sheet =workbook.getSheet("Sheet1");
//			//XSSFSheet sheet2 =workbook.getSheet("Sheet2");
//			int rowCount = sheet.getPhysicalNumberOfRows();
//			
//		
//			
//			//System.out.println("no of row " +rowCount);
//			for(int i=1;i<rowCount;i++) {
//				String value = sheet.getRow(i).getCell(0).getStringCellValue();
//				System.out.println(value);
//				ary.add(value);
//			
//				 Row row = sheet2.createRow(i);
//				 Cell cell = row.createCell(cellnum);
//				 cell.setCellValue((String)value);
//				 
////				 
////				 FileOutputStream out = new FileOutputStream(new File("TestData.xlsx"));
////		            workbook.write(out);
////		            out.close();
//		            System.out.println("howtodoinjava_demo.xlsx written successfully on disk.");
//		        } 
//				//sheet2.createRow(i).createCell(0).setCellValue(value);
//			
////			String value = sheet.getRow(1).getCell(0).getStringCellValue();
////			System.out.println(value);
//			}catch(Exception e) {
//				System.out.println(e);
//			}
//		}
			
		

	
	

